package de.totemshot;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class TotemShotMod implements ModInitializer {
    public static final String MOD_ID = "totemshot";

    // ================= EINSTELLUNGEN =================
    /** Fluggeschwindigkeit in Blöcken pro Sekunde. */
    public static final double SPEED_BLOCKS_PER_SECOND = 4.0;
    /** Maximale Reichweite in Blöcken. */
    public static final double RANGE_BLOCKS = 15.0;
    /** Schaden pro Totem (8 Lebenspunkte = 4 Herzen, ohne Rüstung). */
    public static final float DAMAGE_PER_TOTEM = 8.0f;
    /** Cooldown zwischen zwei Schüssen (40 Ticks = 2 Sekunden). */
    public static final int COOLDOWN_TICKS = 40;

    // Effekte (Dauer in Ticks: 20 Ticks = 1 Sekunde, Amplifier 0 = Stufe I, 1 = Stufe II)
    // Schuss 1: Vergiftung II, 4 Sekunden
    public static final int S1_POISON_TICKS = 4 * 20, S1_POISON_AMP = 1;
    // Schuss 2: Vergiftung II, 4 Sekunden
    public static final int S2_POISON_TICKS = 4 * 20, S2_POISON_AMP = 1;
    // Schuss 3: Schwäche I + Vergiftung I, je 9 Sekunden
    public static final int S3_WEAKNESS_TICKS = 9 * 20, S3_WEAKNESS_AMP = 0;
    public static final int S3_POISON_TICKS = 9 * 20, S3_POISON_AMP = 0;
    // =================================================

    public static EntityType<TotemProjectileEntity> TOTEM_PROJECTILE;

    private static final class ComboState {
        int stage = 1;            // 1 -> 2 -> 3 -> 1 ...
        long lastShot = -1000;
    }

    private static final Map<UUID, ComboState> STATES = new HashMap<>();

    @Override
    public void onInitialize() {
        TOTEM_PROJECTILE = Registry.register(
                Registries.ENTITY_TYPE,
                Identifier.of(MOD_ID, "totem_projectile"),
                FabricEntityTypeBuilder.<TotemProjectileEntity>create(SpawnGroup.MISC, TotemProjectileEntity::new)
                        .dimensions(EntityDimensions.fixed(0.4f, 0.4f))
                        .trackRangeBlocks(64)
                        .trackedUpdateRate(2)
                        .build());

        PayloadTypeRegistry.playC2S().register(ShootPayload.ID, ShootPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ShootPayload.ID,
                (payload, context) -> handleShoot(context.player()));

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> STATES.clear());
    }

    private static void handleShoot(ServerPlayerEntity player) {
        if (!player.isAlive() || player.isSpectator()) {
            return;
        }

        World world = player.getWorld();
        long now = world.getTime();
        ComboState state = STATES.computeIfAbsent(player.getUuid(), id -> new ComboState());

        // Cooldown: 2 Sekunden zwischen den Schüssen
        if (now >= state.lastShot && now - state.lastShot < COOLDOWN_TICKS) {
            return;
        }

        int count = state.stage;                 // so viele Totems jetzt
        state.stage = (state.stage % 3) + 1;     // 1 -> 2 -> 3 -> 1
        state.lastShot = now;

        Vec3d dir = player.getRotationVec(1.0f).normalize();
        Vec3d right = dir.crossProduct(new Vec3d(0, 1, 0)).normalize();
        Vec3d origin = player.getEyePos().add(0, -0.1, 0);

        double[] offsets;
        if (count == 1) {
            offsets = new double[] {0.0};
        } else if (count == 2) {
            offsets = new double[] {-0.25, 0.25};
        } else {
            offsets = new double[] {-0.45, 0.0, 0.45};
        }

        Vec3d velocity = dir.multiply(SPEED_BLOCKS_PER_SECOND / 20.0);

        for (double off : offsets) {
            TotemProjectileEntity totem = new TotemProjectileEntity(TOTEM_PROJECTILE, world);
            totem.setOwner(player);
            totem.setStage(count);
            totem.setPosition(origin.add(right.multiply(off)));
            totem.setVelocity(velocity);
            world.spawnEntity(totem);
        }

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.PLAYERS, 0.8f, 1.0f);

        player.sendMessage(Text.literal("Totem-Schuss: " + count + "x  (nächster: " + state.stage + "x)"), true);
    }
}
