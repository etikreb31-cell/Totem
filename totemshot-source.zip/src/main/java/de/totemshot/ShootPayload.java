package de.totemshot;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Paket vom Client zum Server: "Spieler hat F gedrückt". */
public record ShootPayload() implements CustomPayload {
    public static final CustomPayload.Id<ShootPayload> ID =
            new CustomPayload.Id<>(Identifier.of(TotemShotMod.MOD_ID, "shoot"));

    public static final PacketCodec<RegistryByteBuf, ShootPayload> CODEC =
            PacketCodec.unit(new ShootPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
