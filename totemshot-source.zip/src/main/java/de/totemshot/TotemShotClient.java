package de.totemshot;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.client.util.InputUtil;

public class TotemShotClient implements ClientModInitializer {
    private static KeyBinding shootKey;

    @Override
    public void onInitializeClient() {
        shootKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.totemshot.shoot",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F,
                "category.totemshot.main"));

        // Totem als fliegendes Item darstellen
        EntityRendererRegistry.register(TotemShotMod.TOTEM_PROJECTILE, FlyingItemEntityRenderer::new);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (shootKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    ClientPlayNetworking.send(new ShootPayload());
                }
            }
        });
    }
}
