package de.totemshot;

import java.util.Optional;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FlyingItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/** Das fliegende Totem der Unsterblichkeit. */
public class TotemProjectileEntity extends ProjectileEntity implements FlyingItemEntity {
    private static final ItemStack DISPLAY_STACK = new ItemStack(Items.TOTEM_OF_UNDYING);

    private int stage = 1;          // 1, 2 oder 3 (bestimmt die Effekte)
    private double traveled = 0.0;  // bisher geflogene Strecke in Blöcken

    public TotemProjectileEntity(EntityType<? extends TotemProjectileEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
        this.setInvulnerable(true); // "unsterblich"
    }

    public void setStage(int stage) {
        this.stage = stage;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        // nichts zu synchronisieren
    }

    @Override
    public ItemStack getStack() {
        return DISPLAY_STACK;
    }

    @Override
    public void tick() {
        super.tick();

        World world = this.getWorld();
        Vec3d vel = this.getVelocity();
        Vec3d start = this.getPos();
        Vec3d end = start.add(vel);

        // ---- Client: nur weiterfliegen + Partikel ----
        if (world.isClient) {
            this.setPosition(end);
            world.addParticle(ParticleTypes.TOTEM_OF_UNDYING, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
            return;
        }

        // ---- Server: Treffer prüfen ----
        BlockHitResult blockHit = world.raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, this));
        boolean hitBlock = blockHit.getType() != HitResult.Type.MISS;
        Vec3d limit = hitBlock ? blockHit.getPos() : end;

        final Entity owner = this.getOwner();
        Box search = this.getBoundingBox().stretch(vel).expand(1.0);
        LivingEntity target = null;
        double best = Double.MAX_VALUE;

        for (Entity e : world.getOtherEntities(this, search,
                en -> en instanceof LivingEntity && en.isAlive() && !en.isSpectator() && en != owner)) {
            Box box = e.getBoundingBox().expand(0.3);
            Optional<Vec3d> hit = box.contains(start) ? Optional.of(start) : box.raycast(start, limit);
            if (hit.isPresent()) {
                double d = start.squaredDistanceTo(hit.get());
                if (d < best) {
                    best = d;
                    target = (LivingEntity) e;
                }
            }
        }

        if (target != null) {
            onHitTarget(target, owner);
            this.discard();
            return;
        }

        if (hitBlock) {
            playHitFx(world);
            this.discard();
            return;
        }

        this.setPosition(end);
        this.traveled += vel.length();
        if (this.traveled >= TotemShotMod.RANGE_BLOCKS) {
            this.discard();
        }
    }

    private void onHitTarget(LivingEntity target, Entity owner) {
        World world = this.getWorld();
        DamageSource source = world.getDamageSources().thrown(this, owner);

        // Unverwundbarkeits-Frames aufheben, damit 2-3 Totems jeweils voll treffen
        target.timeUntilRegen = 0;
        boolean damaged = target.damage(source, TotemShotMod.DAMAGE_PER_TOTEM);

        if (damaged) {
            switch (this.stage) {
                case 1 -> target.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.POISON, TotemShotMod.S1_POISON_TICKS, TotemShotMod.S1_POISON_AMP), owner);
                case 2 -> target.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.POISON, TotemShotMod.S2_POISON_TICKS, TotemShotMod.S2_POISON_AMP), owner);
                default -> {
                    target.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.WEAKNESS, TotemShotMod.S3_WEAKNESS_TICKS, TotemShotMod.S3_WEAKNESS_AMP), owner);
                    target.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.POISON, TotemShotMod.S3_POISON_TICKS, TotemShotMod.S3_POISON_AMP), owner);
                }
            }
        }
        playHitFx(world);
    }

    private void playHitFx(World world) {
        if (world instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING,
                    this.getX(), this.getY(), this.getZ(), 12, 0.2, 0.2, 0.2, 0.3);
        }
        world.playSound(null, this.getX(), this.getY(), this.getZ(),
                SoundEvents.ENTITY_ARROW_HIT, SoundCategory.PLAYERS, 1.0f, 1.2f);
    }
}
