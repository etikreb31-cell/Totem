# Totem Shot (Fabric 1.21)

- Taste **F**: Totem der Unsterblichkeit schießen (Taste in den Steuerungs-Einstellungen änderbar)
- Reihenfolge: 1 Totem -> 2 Totems -> 3 Totems -> wieder 1 ...
- Cooldown 2 s, Geschwindigkeit 4 Blöcke/s, Reichweite 15 Blöcke, 4 Herzen Schaden pro Totem
- Benötigt: Fabric Loader, Fabric API (1.21), Java 21

Alle Werte stehen oben in `TotemShotMod.java`.
